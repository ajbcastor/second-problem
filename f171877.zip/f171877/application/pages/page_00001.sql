prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.4'
,p_default_workspace_id=>110605810036407028651
,p_default_application_id=>171877
,p_default_id_offset=>0
,p_default_owner=>'WKSP_AJBCASTOR'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>'Home'
,p_alias=>'HOME'
,p_step_title=>'second-problem'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
,p_last_updated_by=>'AJB.CASTOR@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20240517074437'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(110935271494839699504)
,p_plug_name=>'second-problem'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(110935040663643699341)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'## Second Problem',
'Development Assumptions:',
' - All data manipulation to be done on top of APEX Collections',
' - Up to the candidate to decide if save is done in each Interactive Grid or at page level',
'     - Expect to be asked why you made either decision',
' Development guidelines:',
' - Create application with title ''Manage Employees'':',
'    - Create page manage employee',
'         - Create region with title ''Dashboards'' that includes:',
'             - 1 badge with total number of employees',
'             - 1 bar chart with number of employees per department',
'         - Create region named ''Assign employee'', which is expected to contain:',
'             - 2 interactive grids defined as master / detail',
'                 - The master interactive grid will have the following functionality:',
'                     - Data based on department table',
'                     - Fields:',
'                         - Name',
'                         - Cost Center',
'                     - Remove button in the interactive grid toolbar',
'                        - Button only available for click once a department record is selected, and only one at a time',
'                     - Implement remove department with an AJAX callback from master',
'                         - Remove a department will remove the references to those departments from the employees assigned to it',
'                 - The detail interactive grid will have the following functionality:',
'                     - Data based on employees',
'                     - Fields:',
'                         - Department name',
'                         - First Name',
'                         - Last Name',
'                         - Email',
'                         - Hire Date',
'                         - City',
'                         - Country',
'                         - Job',
'                     - Add/Remove buttons in the interactive grid toolbar',
'                     - Add button will open a popup dialog to search for an employee and will have a OK button at the bottom right corner and close at the left bottom corner:',
'                         - OK persists the employee to the collection',
'                         - Close, closes the dialog',
'                         - Form fields:',
'                             - First Name',
'                             - Last Name',
'                             - Email',
'                             - Hire Date (Date picker)',
'                             - City',
'                             - Country',
'                             - Job (LOV)',
'                     - Remove button will remove users with an AJAX callback',
' - After you finish, export the application as a single file and place in the folder `second-problem/webapp`'))
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_imp.component_end;
end;
/
